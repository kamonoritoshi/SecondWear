package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Nhom1DatnApplication {

	public static void main(String[] args) {
		SpringApplication.run(Nhom1DatnApplication.class, args);
	}

}
